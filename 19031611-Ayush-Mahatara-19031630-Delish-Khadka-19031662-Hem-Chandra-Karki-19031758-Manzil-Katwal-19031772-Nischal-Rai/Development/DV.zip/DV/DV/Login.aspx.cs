﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DV
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                HttpCookie userCookie = Request.Cookies["userCookie"];
                if (userCookie == null)
                {
                    return;
                }
                else if (!string.IsNullOrEmpty(userCookie.Values["username"]))
                {
                    Response.Redirect("/View/Simple_Forms/Actor.aspx");
                }
            }
            catch (Exception)
            {
                Response.Write("<script>alert('error')</script>");
            }
        }

        protected void LoginBtn_Click(object sender, EventArgs e)
        {
            string sqlcon = System.Configuration.ConfigurationManager.AppSettings.Get("MyConnection").ToString();
            SqlConnection con = new SqlConnection(sqlcon);

            string sql = "SELECT * FROM [User] where UserName= '" + inputUserName.Text + "' and UserPassword = '" + inputPassword.Text + "' and UserType='" + UserTypeDropDown.SelectedItem.ToString() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                HttpCookie userCookie = new HttpCookie("userCookie");
                userCookie.Values.Add("UserName", inputUserName.Text);
                userCookie.Values.Add("Password", inputPassword.Text);
                userCookie.Values.Add("UserType", UserTypeDropDown.SelectedItem.ToString());

               // userCookie.Expires = DateTime.Now.AddMinutes(1);
                Response.Cookies.Add(userCookie);


                Response.Write("<script>alert('Login successful')</script>");
                if (UserTypeDropDown.SelectedIndex == 0)
                {
                    Response.Redirect("/View/Simple_Forms/Actor.aspx");
                }
                else if (UserTypeDropDown.SelectedIndex == 1)
                {
                    Response.Redirect("/View/Simple_Forms/Actor.aspx");
                }
            }
            else
            {
                alrtError.Text = "Invalid Username and/or Password!!";
            }

        }
    }
}