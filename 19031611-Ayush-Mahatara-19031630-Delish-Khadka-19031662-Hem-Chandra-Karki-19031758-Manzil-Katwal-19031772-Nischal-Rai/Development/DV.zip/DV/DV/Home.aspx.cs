﻿using DV.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;

namespace DV
{
    public partial class WebForm12 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Home getActor= new Home();
                ActorDropDown.DataSource = getActor.GetActor();
                ActorDropDown.DataBind();
                ActorDropDown.DataTextField = "ActorSurname";
                ActorDropDown.DataValueField = "ActorNumber";
                ActorDropDown.DataBind();
                ActorDropDown.Items.Insert(0, new ListItem("-- Select Actor Last Name --", ""));

                ListView();
                
                Home getNewActor= new Home();
                NewActorDropDown.DataSource = getNewActor.GetActor();
                NewActorDropDown.DataBind();
                NewActorDropDown.DataTextField = "ActorSurname";
                NewActorDropDown.DataValueField = "ActorNumber";
                NewActorDropDown.DataBind();
                NewActorDropDown.Items.Insert(0, new ListItem("-- Select Actor Last Name --", ""));

                NewListView();
                
                Home getNewMember= new Home();
                MemberDropDown.DataSource = getNewMember.GetMember();
                MemberDropDown.DataBind();
                MemberDropDown.DataTextField = "MemberLastName";
                MemberDropDown.DataValueField = "MemberNumber";
                MemberDropDown.DataBind();
                MemberDropDown.Items.Insert(0, new ListItem("-- Select Member Last Name --", ""));

                MemberListView();
               

                DVDByOrderListView();

                Home getCopyNumber = new Home();
                CopyNumberDropDown.DataSource = getNewMember.GetCopyNumber();
                CopyNumberDropDown.DataBind();
                CopyNumberDropDown.DataTextField = "CopyNumber";
                CopyNumberDropDown.DataValueField = "CopyNumber";
                CopyNumberDropDown.DataBind();
                CopyNumberDropDown.Items.Insert(0, new ListItem("-- Select Copy Number --", ""));

                CopyNumberAndDVDView();

                AlphabetMemberView();
                DVDNoLoanView();

            }
        }

        protected void ListView()
        {
            try
            {
                Home p = new Home();
                DVDTitleGV.DataSource = p.GetDVDTitle();
                DVDTitleGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }

        protected void ActionChange(object sender, EventArgs e)
        {
            try
            {
                Home p = new Home();
                DVDTitleGV.DataSource = p.GetDVDTitle(int.Parse(ActorDropDown.SelectedItem.Value));
                DVDTitleGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }

        protected void NewListView()
        {
            try
            {
                Home p = new Home();
                CopiesGV.DataSource = p.GetTotalMovies();
                CopiesGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }

        protected void NewActionChange(object sender, EventArgs e)
        {
            try
            {
                Home p = new Home();
                CopiesGV.DataSource = p.GetTotalMovies(int.Parse(NewActorDropDown.SelectedItem.Value));
                CopiesGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }


        protected void MemberListView()
        {
            try
            {
                Home p = new Home();
                DVDLastMonthGV.DataSource = p.GetDVDLastMonth();
                DVDLastMonthGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }

        protected void MemberDropDown_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Home p = new Home();
                DVDLastMonthGV.DataSource = p.GetDVDLastMonth(int.Parse(MemberDropDown.SelectedItem.Value));
                DVDLastMonthGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }

        protected void DVDByOrderListView()
        {
            try
            {
                Home p = new Home();
                DVDByOrderGV.DataSource = p.GetDVDByOrder();
                DVDByOrderGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }

        protected void CopyNumberAndDVDView()
        {
            try
            {
                Home p = new Home();
                CopyNumberAndDVDGV.DataSource = p.GetCopyNumberAndDVD();
                CopyNumberAndDVDGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }

        protected void CopyNumberDropDown_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Home p = new Home();
                CopyNumberAndDVDGV.DataSource = p.GetCopyNumberAndDVD(int.Parse(CopyNumberDropDown.SelectedItem.Value));
                CopyNumberAndDVDGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }

        protected void AlphabetMemberView()
        {
            try
            {
                Home p = new Home();
                AlphabetMemberGV.DataSource = p.GetAlphabetMember();
                AlphabetMemberGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }
        
        protected void DVDNoLoanView()
        {
            try
            {
                Home p = new Home();
                DVDNoLoanGV.DataSource = p.GetDVDNoLoan();
                DVDNoLoanGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }

        protected void DVDLastMonthGV_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}