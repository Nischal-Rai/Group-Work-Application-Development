﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;
using System.Windows.Forms;
using MessageBox = System.Windows.Forms.MessageBox;

namespace DV
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    HttpCookie userCookie = Request.Cookies["userCookie"];
                    if (userCookie == null)
                    {
                        Response.Redirect("~/Login.aspx");
                    }

                    //cookie found
                    if (!string.IsNullOrEmpty(userCookie.Values["userType"]))
                    {
                        string usertype = userCookie.Values["userType"].ToString();
                        if (usertype == "Staff")
                        {
                            Response.Write("<script>alert('welcome Staff')</script>");
                            Response.Redirect("~/403Forbidden.aspx");
                        }
                    }
                    ListView();
                }
            }
            catch (Exception)
            {
                Response.Write("<script>alert('exception)</script>");
            }
        }

        protected void addBtn_Click(object sender, EventArgs e)
        {
            Studio AddStudio = new Studio();
            AddStudio.AddStudio(inputStudioName.Text);
            pnlSuccess.Visible = true;
            alrtSuccess.Text = "Studio Successfully Added!!";
            Clear();
            ListView();
        }

        protected void updateBtn_Click(object sender, EventArgs e)
        {
            Studio UpdateStudio = new Studio();
            int id = int.Parse(inputStudioNumber.Text);
            UpdateStudio.UpdateStudio(id, inputStudioName.Text);

            pnlSuccess.Visible = true;
            alrtSuccess.Text = "Studio Successfully Updated!!";
            Clear();
            ListView();
        }

        protected void ListView()
        {
            try
            {
                Studio p = new Studio();
                StudioGV.DataSource = p.GetStudio();
                StudioGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }

        //edit-delete
        protected void GV_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "EditStudio":
                        int index = Convert.ToInt32(e.CommandArgument);
                        GridViewRow row = StudioGV.Rows[index];

                        inputStudioNumber.Text = row.Cells[0].Text;
                        inputStudioName.Text = row.Cells[1].Text;
                        break;

                    case "DeleteStudio":
                        DialogResult dialogResult = MessageBox.Show("Are you Sure??", "Delete Studio", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            Studio DeleteStudio = new Studio();
                            int token = Convert.ToInt32(e.CommandArgument);
                            GridViewRow record = StudioGV.Rows[token];

                            DeleteStudio.DeleteStudio(int.Parse(record.Cells[0].Text));
                            alrtSuccess.Text = "Studio Successfully Deleted!!";
                            ListView();
                        }
                        else if (dialogResult == DialogResult.No)
                        {
                            break;
                        }

                        break;

                    default:
                        return;
                }
            }
            catch (Exception ex)
            {
                pnlError.Visible = true;
                alrtError.Text = ex.Message;
            }
        }

        public void Clear()
        {
            inputStudioNumber.Text = "";
            inputStudioName.Text = "";
        }

        protected void clearBtn_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}