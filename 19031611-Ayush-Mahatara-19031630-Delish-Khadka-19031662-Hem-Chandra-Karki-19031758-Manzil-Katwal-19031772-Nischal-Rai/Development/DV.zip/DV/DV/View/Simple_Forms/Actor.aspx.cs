﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;
using System.Windows.Forms;
using MessageBox = System.Windows.Forms.MessageBox;

namespace DV
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    HttpCookie userCookie = Request.Cookies["userCookie"];
                    if (userCookie == null)
                    {
                        Response.Redirect("~/Login.aspx");
                    }

                    //cookie found
                    if (!string.IsNullOrEmpty(userCookie.Values["userType"]))
                    {
                        string usertype = userCookie.Values["userType"].ToString();
                        if (usertype == "Staff")
                        {
                            Response.Write("<script>alert('welcome Staff')</script>");
                            Response.Redirect("~/403Forbidden.aspx");
                        }
                    }
                    ListView();
                }
            }
            catch (Exception)
            {
                Response.Write("<script>alert('exception)</script>");
            }
        }
        //add button
        protected void addBtn_Click(object sender, EventArgs e)
        {
            Actor AddActor = new Actor();
            AddActor.AddActor(inputActorFirstName.Text, inputActorSurName.Text);
            pnlSuccess.Visible = true;
            alrtSuccess.Text = "Actor Successfully Added!!";
            Clear();
            ListView();
        }

        //update button
        protected void updateBtn_Click(object sender, EventArgs e)
        {
            Actor UpdateActor = new Actor();
            int id = int.Parse(inputActorNumber.Text);
            UpdateActor.UpdateActor(id, inputActorFirstName.Text, inputActorSurName.Text);

            pnlSuccess.Visible = true;
            alrtSuccess.Text = "Actor Successfully Updated!!";
            Clear();
            ListView();
        }

        protected void ListView()
        {
            try
            {
                Actor p = new Actor();
                ActorGV.DataSource = p.GetActor();
                ActorGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }

        //view rows and perform edit and delete action of actor
        protected void GV_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "EditActor":
                        int index = Convert.ToInt32(e.CommandArgument);
                        GridViewRow row = ActorGV.Rows[index];

                        inputActorNumber.Text = row.Cells[0].Text;
                        inputActorFirstName.Text = row.Cells[1].Text;
                        inputActorSurName.Text = row.Cells[2].Text;
                        break;

                    case "DeleteActor":
                        DialogResult dialogResult = MessageBox.Show("Are you Sure??", "Delete Actor", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            Actor DeleteActor = new Actor();
                            int token = Convert.ToInt32(e.CommandArgument);
                            GridViewRow record = ActorGV.Rows[token];

                            DeleteActor.DeleteActor(int.Parse(record.Cells[0].Text));
                            alrtSuccess.Text = "Actor Successfully Deleted!!";
                            ListView();
                        }
                        else if (dialogResult == DialogResult.No)
                        {
                            break;
                        }

                        break;

                    default:
                        return;
                }
            }
            catch (Exception ex)
            {
                pnlError.Visible = true;
                alrtError.Text = ex.Message;
            }
        }

        public void Clear()
        {
            inputActorNumber.Text = "";
            inputActorFirstName.Text = "";
            inputActorSurName.Text = "";
        }

        protected void clearBtn_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}