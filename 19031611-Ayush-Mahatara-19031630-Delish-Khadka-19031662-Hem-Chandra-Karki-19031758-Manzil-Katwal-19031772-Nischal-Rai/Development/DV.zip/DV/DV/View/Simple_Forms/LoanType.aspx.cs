﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;
using System.Windows.Forms;
using MessageBox = System.Windows.Forms.MessageBox;

namespace DV
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    HttpCookie userCookie = Request.Cookies["userCookie"];
                    if (userCookie == null)
                    {
                        Response.Redirect("~/Login.aspx");
                    }

                    //cookie found
                    if (!string.IsNullOrEmpty(userCookie.Values["userType"]))
                    {
                        string usertype = userCookie.Values["userType"].ToString();
                        if (usertype == "Staff")
                        {
                            Response.Write("<script>alert('welcome Staff')</script>");
                            Response.Redirect("~/403Forbidden.aspx");
                        }
                    }
                    ListView();
                }
            }
            catch (Exception)
            {
                Response.Write("<script>alert('exception)</script>");
            }
        }
        //add button
        protected void addBtn_Click(object sender, EventArgs e)
        {
            LoanType AddLoanType = new LoanType();
            AddLoanType.AddLoanType(inputLoanType.Text, int.Parse(inputLoanDuration.Text));
            pnlSuccess.Visible = true;
            alrtSuccess.Text = "DVD Category Successfully Added!!";
            Clear();
            ListView();
        }

        //update
        protected void updateBtn_Click(object sender, EventArgs e)
        {
            LoanType UpdateLoanType = new LoanType();
            int id = int.Parse(inputLoanTypeNumber.Text);
            UpdateLoanType.UpdateLoanType(id, inputLoanType.Text, int.Parse(inputLoanDuration.Text));

            pnlSuccess.Visible = true;
            alrtSuccess.Text = "DVD Category Successfully Updated!!";
            Clear();
            ListView();
        }


        protected void ListView()
        {
            try
            {
                LoanType p = new LoanType();
                LoanTypeGV.DataSource = p.GetLoanType();
                LoanTypeGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }

        //edit update
        protected void GV_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "EditLoanType":
                        int index = Convert.ToInt32(e.CommandArgument);
                        GridViewRow row = LoanTypeGV.Rows[index];

                        inputLoanTypeNumber.Text = row.Cells[0].Text;
                        inputLoanType.Text = row.Cells[1].Text;
                        inputLoanDuration.Text = row.Cells[2].Text;
                        break;

                    case "DeleteLoanType":
                        DialogResult dialogResult = MessageBox.Show("Are you Sure??", "Delete Loan Type", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            LoanType DeleteLoanType = new LoanType();
                            int token = Convert.ToInt32(e.CommandArgument);
                            GridViewRow record = LoanTypeGV.Rows[token];

                            DeleteLoanType.DeleteLoanType(int.Parse(record.Cells[0].Text));
                            alrtSuccess.Text = "LoanType Successfully Deleted!!";
                            ListView();
                        }
                        else if (dialogResult == DialogResult.No)
                        {
                            break;
                        }

                        break;

                    default:
                        return;
                }
            }
            catch (Exception ex)
            {
                pnlError.Visible = true;
                alrtError.Text = ex.Message;
            }
        }

        public void Clear()
        {
            inputLoanTypeNumber.Text = "";
            inputLoanType.Text = "";
            inputLoanDuration.Text = "";
        }

        protected void clearBtn_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}