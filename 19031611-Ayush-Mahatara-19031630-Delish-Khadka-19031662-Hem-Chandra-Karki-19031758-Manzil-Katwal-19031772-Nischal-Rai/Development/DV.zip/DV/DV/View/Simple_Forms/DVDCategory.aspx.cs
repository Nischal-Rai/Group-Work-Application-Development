﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;
using System.Windows.Forms;
using MessageBox = System.Windows.Forms.MessageBox;

namespace DV
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    HttpCookie userCookie = Request.Cookies["userCookie"];
                    if (userCookie == null)
                    {
                        Response.Redirect("~/Login.aspx");
                    }

                    //cookie found
                    if (!string.IsNullOrEmpty(userCookie.Values["userType"]))
                    {
                        string usertype = userCookie.Values["userType"].ToString();
                        if (usertype == "Staff")
                        {
                            Response.Write("<script>alert('welcome Staff')</script>");
                            Response.Redirect("~/403Forbidden.aspx");
                        }
                    }
                    ListView();
                }
            }
            catch (Exception)
            {
                Response.Write("<script>alert('exception)</script>");
            }
        }

        //add button
        protected void addBtn_Click(object sender, EventArgs e)
        {
            DVDCategory AddDVDCategory = new DVDCategory();
            AddDVDCategory.AddDVDCategory(inputCategoryDescription.Text, bool.Parse(AgeRestrictedDropDown.SelectedItem.Value));
            pnlSuccess.Visible = true;
            alrtSuccess.Text = "DVD Category Successfully Added!!";
            Clear();
            ListView();
        }

        //update button
        protected void updateBtn_Click(object sender, EventArgs e)
        {
            DVDCategory UpdateDVDCategory = new DVDCategory();
            int id = int.Parse(inputCategoryNumber.Text);
            UpdateDVDCategory.UpdateDVDCategory(id, inputCategoryDescription.Text, bool.Parse(AgeRestrictedDropDown.SelectedItem.Value));

            pnlSuccess.Visible = true;
            alrtSuccess.Text = "DVD Category Successfully Updated!!";
            Clear();
            ListView();
        }

        //view details
        protected void ListView()
        {
            try
            {
                DVDCategory p = new DVDCategory();
                DVDCategoryGV.DataSource = p.GetDVDCategory();
                DVDCategoryGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }

        //view data and apply edit delete action
        protected void GV_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "EditDVDCategory":
                        int index = Convert.ToInt32(e.CommandArgument);
                        GridViewRow row = DVDCategoryGV.Rows[index];

                        inputCategoryNumber.Text = row.Cells[0].Text;
                        inputCategoryDescription.Text = row.Cells[1].Text;
                        AgeRestrictedDropDown.SelectedItem.Value = row.Cells[2].Text;
                        break;

                    case "DeleteDVDCategory":
                        DialogResult dialogResult = MessageBox.Show("Are you Sure??", "Delete DVD Category", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            DVDCategory DeleteDVDCategory = new DVDCategory();
                            int token = Convert.ToInt32(e.CommandArgument);
                            GridViewRow record = DVDCategoryGV.Rows[token];

                            DeleteDVDCategory.DeleteDVDCategory(int.Parse(record.Cells[0].Text));
                            alrtSuccess.Text = "DVDCategory Successfully Deleted!!";
                            ListView();
                        }
                        else if (dialogResult == DialogResult.No)
                        {
                            break;
                        }

                        break;

                    default:
                        return;
                }
            }
            catch (Exception ex)
            {
                pnlError.Visible = true;
                alrtError.Text = ex.Message;
            }
        }

        public void Clear()
        {
            inputCategoryNumber.Text = "";
            inputCategoryDescription.Text = "";
            AgeRestrictedDropDown.SelectedItem.Value = "";
        }

        protected void clearBtn_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}