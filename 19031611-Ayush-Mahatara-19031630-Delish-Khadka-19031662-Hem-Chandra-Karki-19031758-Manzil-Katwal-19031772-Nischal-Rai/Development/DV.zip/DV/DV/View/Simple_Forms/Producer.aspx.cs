﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;
using System.Windows.Forms;
using MessageBox = System.Windows.Forms.MessageBox;

namespace DV
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    HttpCookie userCookie = Request.Cookies["userCookie"];
                    if (userCookie == null)
                    {
                        Response.Redirect("~/Login.aspx");
                    }

                    //cookie found
                    if (!string.IsNullOrEmpty(userCookie.Values["userType"]))
                    {
                        string usertype = userCookie.Values["userType"].ToString();
                        if (usertype == "Staff")
                        {
                            Response.Write("<script>alert('welcome Staff')</script>");
                            Response.Redirect("~/403Forbidden.aspx");
                        }
                    }
                    ListView();
                }
            }
            catch (Exception)
            {
                Response.Write("<script>alert('exception)</script>");
            }
        }
        //add button
        protected void addBtn_Click(object sender, EventArgs e)
        {
            DVD AddProducer = new DVD();
            AddProducer.AddProducer(inputProducerName.Text);
            pnlSuccess.Visible = true;
            alrtSuccess.Text = "Producer Successfully Added!!";
            Clear();
            ListView();
        }

        protected void updateBtn_Click(object sender, EventArgs e)
        {
            DVD UpdateProducer = new DVD();
            int id = int.Parse(inputProducerNumber.Text);
            UpdateProducer.UpdateProducer(id, inputProducerName.Text);

            pnlSuccess.Visible = true;
            alrtSuccess.Text = "Producer Successfully Updated!!";
            Clear();
            ListView();
        }


        protected void ListView()
        {
            try
            {
                DVD p = new DVD();
                ProducerGV.DataSource = p.GetProducer();
                ProducerGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }

        //edit-delete
        protected void GV_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "EditProducer":
                        int index = Convert.ToInt32(e.CommandArgument);
                        GridViewRow row = ProducerGV.Rows[index];

                        inputProducerNumber.Text = row.Cells[0].Text;
                        inputProducerName.Text = row.Cells[1].Text;
                        break;

                    case "DeleteProducer":
                        DialogResult dialogResult = MessageBox.Show("Are you Sure??", "Delete Producer", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            DVD DeleteProducer = new DVD();
                            int token = Convert.ToInt32(e.CommandArgument);
                            GridViewRow record = ProducerGV.Rows[token];

                            DeleteProducer.DeleteProducer(int.Parse(record.Cells[0].Text));
                            alrtSuccess.Text = "Producer Successfully Deleted!!";
                            ListView();
                        }
                        else if (dialogResult == DialogResult.No)
                        {
                            break;
                        }

                        break;

                    default:
                        return;
                }
            }
            catch (Exception ex)
            {
                pnlError.Visible = true;
                alrtError.Text = ex.Message;
            }
        }

        public void Clear()
        {
            inputProducerNumber.Text = "";
            inputProducerName.Text = "";
        }

        protected void clearBtn_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}