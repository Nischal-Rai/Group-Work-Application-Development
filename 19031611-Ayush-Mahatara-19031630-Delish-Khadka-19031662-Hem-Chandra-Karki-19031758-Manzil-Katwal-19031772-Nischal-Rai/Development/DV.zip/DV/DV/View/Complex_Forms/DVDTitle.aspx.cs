﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;
using System.Windows.Forms;
using MessageBox = System.Windows.Forms.MessageBox;

namespace DV
{
    public partial class WebForm11 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    HttpCookie userCookie = Request.Cookies["userCookie"];
                    if (userCookie == null)
                    {
                        Response.Redirect("~/Login.aspx");
                    }

                    //cookie found
                    if (!string.IsNullOrEmpty(userCookie.Values["userType"]))
                    {
                        string usertype = userCookie.Values["userType"].ToString();
                        if (usertype == "Staff")
                        {
                            Response.Write("<script>alert('welcome Staff')</script>");
                            Response.Redirect("~/403Forbidden.aspx");
                        }
                    }
                    DVDCategory getDVDCategory = new DVDCategory();
                    DVDCategoryDropDown.DataSource = getDVDCategory.GetDVDCategory();
                    DVDCategoryDropDown.DataBind();
                    DVDCategoryDropDown.DataTextField = "CategoryDescription";
                    DVDCategoryDropDown.DataValueField = "CategoryNumber";
                    DVDCategoryDropDown.DataBind();
                    DVDCategoryDropDown.Items.Insert(0, new ListItem("-- Select DVD Category --", ""));

                    Studio getStudioCategory = new Studio();
                    StudioDropDown.DataSource = getStudioCategory.GetStudio();
                    StudioDropDown.DataBind();
                    StudioDropDown.DataTextField = "StudioName";
                    StudioDropDown.DataValueField = "StudioNumber";
                    StudioDropDown.DataBind();
                    StudioDropDown.Items.Insert(0, new ListItem("-- Select Studio --", ""));

                    DVD getProducerCategory = new DVD();
                    ProducerDropDown.DataSource = getProducerCategory.GetProducer();
                    ProducerDropDown.DataBind();
                    ProducerDropDown.DataTextField = "ProducerName";
                    ProducerDropDown.DataValueField = "ProducerNumber";
                    ProducerDropDown.DataBind();
                    ProducerDropDown.Items.Insert(0, new ListItem("-- Select A Producer --", ""));
                    ListView();
                }
            }
            catch (Exception)
            {
                Response.Write("<script>alert('exception)</script>");
            }
        }

        protected void addBtn_Click(object sender, EventArgs e)
        {
            if (DVDCategoryDropDown.SelectedValue == "" && StudioDropDown.SelectedItem.Value == "" || ProducerDropDown.SelectedItem.Value == "")
            {
                lblError.Text = "**DVD Category, Studio and Producer is required**";
                return;
            }
            else
            {
                DVDTitle AddDVDTitle = new DVDTitle();
                AddDVDTitle.AddDVDTitle(inputDVDTitle.Text, decimal.Parse(inputStandardCharge.Text), decimal.Parse(inputPenaltyCharge.Text), DVDCategoryDropDown.SelectedItem.Value, StudioDropDown.SelectedItem.Value, ProducerDropDown.SelectedItem.Value);
                pnlSuccess.Visible = true;
                alrtSuccess.Text = "DVDTitle Successfully Added!!";
                Clear();
                ListView();
            }

        }

        protected void updateBtn_Click(object sender, EventArgs e)
        {
            if (DVDCategoryDropDown.SelectedValue == "" && StudioDropDown.SelectedItem.Value == "" || ProducerDropDown.SelectedItem.Value == "")
            {
                lblError.Text = "**DVD Category, Studio and Producer is required**";
                return;
            }
            else
            {
                DVDTitle UpdateStudio = new DVDTitle();
                int id = int.Parse(inputDVDNumber.Text);
                UpdateStudio.UpdateDVDTitle(id, inputDVDTitle.Text, decimal.Parse(inputStandardCharge.Text), decimal.Parse(inputPenaltyCharge.Text), DVDCategoryDropDown.SelectedItem.Value, StudioDropDown.SelectedItem.Value, ProducerDropDown.SelectedItem.Value);

                pnlSuccess.Visible = true;
                alrtSuccess.Text = "DVDTitle Successfully Updated!!";
                Clear();
                ListView();
            }
        }

        protected void ListView()
        {
            try
            {
                DVDTitle p = new DVDTitle();
                DVDTitleGV.DataSource = p.GetDVDTitle();
                DVDTitleGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }


        protected void GV_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "EditDVDTitle":
                        int index = Convert.ToInt32(e.CommandArgument);
                        GridViewRow row = DVDTitleGV.Rows[index];

                        inputDVDNumber.Text = row.Cells[0].Text;
                        inputDVDTitle.Text = row.Cells[1].Text;
                        inputStandardCharge.Text = row.Cells[2].Text;
                        inputPenaltyCharge.Text = row.Cells[3].Text;
                        DVDCategoryDropDown.SelectedItem.Value = row.Cells[4].Text;
                        StudioDropDown.SelectedItem.Value = row.Cells[5].Text;
                        ProducerDropDown.SelectedItem.Value = row.Cells[5].Text;
                        break;

                    case "DeleteDVDTitle":
                        DialogResult dialogResult = MessageBox.Show("Are you Sure??", "Delete DVDTitle", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            DVDTitle DeleteDVDTitle = new DVDTitle();
                            int token = Convert.ToInt32(e.CommandArgument);
                            GridViewRow record = DVDTitleGV.Rows[token];

                            DeleteDVDTitle.DeleteDVDTitle(int.Parse(record.Cells[0].Text));
                            alrtSuccess.Text = "DVDTitle Successfully Deleted!!";
                            ListView();
                        }
                        else if (dialogResult == DialogResult.No)
                        {
                            break;
                        }

                        break;

                    default:
                        return;
                }
            }
            catch (Exception ex)
            {
                pnlError.Visible = true;
                alrtError.Text = ex.Message;
            }
        }

        public void Clear()
        {
            inputDVDNumber.Text = "";
            inputDVDTitle.Text = "";
            inputStandardCharge.Text = "";
            inputPenaltyCharge.Text = "";
            DVDCategoryDropDown.SelectedIndex = 0;
            StudioDropDown.SelectedIndex = 0;
            ProducerDropDown.SelectedIndex = 0;
        }

        protected void clearBtn_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}