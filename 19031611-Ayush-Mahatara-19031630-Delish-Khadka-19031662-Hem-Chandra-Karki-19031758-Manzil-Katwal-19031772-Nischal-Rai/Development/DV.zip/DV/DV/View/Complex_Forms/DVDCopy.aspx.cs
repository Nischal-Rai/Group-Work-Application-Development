﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;
using System.Windows.Forms;
using MessageBox = System.Windows.Forms.MessageBox;

namespace DV
{
    public partial class WebForm8 : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    HttpCookie userCookie = Request.Cookies["userCookie"];
                    if (userCookie == null)
                    {
                        Response.Redirect("~/Login.aspx");
                    }

                    //cookie found
                    if (!string.IsNullOrEmpty(userCookie.Values["userType"]))
                    {
                        string usertype = userCookie.Values["userType"].ToString();
                        if (usertype == "Staff")
                        {
                            Response.Write("<script>alert('welcome Staff')</script>");
                            Response.Redirect("~/403Forbidden.aspx");
                        }
                    }
                    DVDTitle getDVDTitle = new DVDTitle();
                    DVDTitleDropDown.DataSource = getDVDTitle.GetDVDTitle();
                    DVDTitleDropDown.DataBind();
                    DVDTitleDropDown.DataTextField = "DVDTitle";
                    DVDTitleDropDown.DataValueField = "DVDNumber";
                    DVDTitleDropDown.DataBind();
                    DVDTitleDropDown.Items.Insert(0, new ListItem("-- Select DVD Title --", ""));
                    ListView();
                }
            }
            catch (Exception)
            {
                Response.Write("<script>alert('exception)</script>");
            }
        }

        protected void addBtn_Click(object sender, EventArgs e)
        {
            if (DVDTitleDropDown.SelectedValue == "")
            {
                lblError.Text = "**DVD Title is required**";
                return;
            }
            else
            {
                DVDCopy AddDVDCopy = new DVDCopy();
                AddDVDCopy.AddDVDCopy(Convert.ToDateTime(inputDatePurchased.Text), DVDTitleDropDown.SelectedItem.Value);
                pnlSuccess.Visible = true;
                alrtSuccess.Text = "DVD Copy Successfully Added!!";
                Clear();
                ListView();
            }

        }

        protected void updateBtn_Click(object sender, EventArgs e)
        {
            if (DVDTitleDropDown.SelectedValue == "")
            {
                lblError.Text = "**DVD Title is required**";
                return;
            }
            else
            {
                DVDCopy UpdateDVDCopy = new DVDCopy();
                int id = Int32.Parse(inputCopyNumber.Text);
                UpdateDVDCopy.UpdateDVDCopy(id, Convert.ToDateTime(inputDatePurchased.Text), DVDTitleDropDown.SelectedItem.Value);

                pnlSuccess.Visible = true;
                alrtSuccess.Text = "DVD Copy Successfully Updated!!";
                Clear();
                ListView();
            }

        }

        protected void ListView()
        {
            try
            {
                DVDCopy p = new DVDCopy();
                DVDCopyGV.DataSource = p.GetDVDCopy();
                DVDCopyGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }


        protected void GV_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "EditDVDCopy":
                        int index = Convert.ToInt32(e.CommandArgument);
                        GridViewRow row = DVDCopyGV.Rows[index];

                        inputCopyNumber.Text = row.Cells[0].Text;
                        inputDatePurchased.Text = row.Cells[1].Text;
                        DVDTitleDropDown.SelectedItem.Value = row.Cells[2].Text;
                        break;

                    case "DeleteDVDCopy":
                        DialogResult dialogResult = MessageBox.Show("Are you Sure??", "Delete DVDCopy", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            DVDCopy DeleteDVDCopy = new DVDCopy();
                            int token = Convert.ToInt32(e.CommandArgument);
                            GridViewRow record = DVDCopyGV.Rows[token];

                            DeleteDVDCopy.DeleteDVDCopy(int.Parse(record.Cells[0].Text));
                            alrtSuccess.Text = "DVDCopy Successfully Deleted!!";
                            ListView();
                        }
                        else if (dialogResult == DialogResult.No)
                        {
                            break;
                        }

                        break;

                    default:
                        return;
                }
            }
            catch (Exception ex)
            {
                pnlError.Visible = true;
                alrtError.Text = ex.Message;
            }
        }

        public void Clear()
        {
            inputCopyNumber.Text = "";
            inputDatePurchased.Text = "";
            inputDatePurchased.Text = "";
            DVDTitleDropDown.SelectedIndex = 0;
        }

        protected void clearBtn_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}