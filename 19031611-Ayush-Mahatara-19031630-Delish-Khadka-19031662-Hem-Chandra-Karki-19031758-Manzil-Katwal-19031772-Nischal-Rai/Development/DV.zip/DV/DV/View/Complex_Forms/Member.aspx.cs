﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;
using System.Windows.Forms;
using MessageBox = System.Windows.Forms.MessageBox;

namespace DV
{
    public partial class WebForm9 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    HttpCookie userCookie = Request.Cookies["userCookie"];
                    if (userCookie == null)
                    {
                        Response.Redirect("~/Login.aspx");
                    }

                    //cookie found
                    if (!string.IsNullOrEmpty(userCookie.Values["userType"]))
                    {
                        string usertype = userCookie.Values["userType"].ToString();
                        if (usertype == "Staff")
                        {
                            Response.Write("<script>alert('welcome Staff')</script>");
                            Response.Redirect("~/403Forbidden.aspx");
                        }
                    }
                    MembershipCategory getMembershipCategory = new MembershipCategory();
                    MembershipCategoryDropDown.DataSource = getMembershipCategory.GetMembershipCategory();
                    MembershipCategoryDropDown.DataBind();
                    MembershipCategoryDropDown.DataTextField = "MembershipCategoryDescription";
                    MembershipCategoryDropDown.DataValueField = "MembershipCategoryNumber";
                    MembershipCategoryDropDown.DataBind();
                    MembershipCategoryDropDown.Items.Insert(0, new ListItem("-- Select Membership Category --", ""));
                    ListView();
                }
            }
            catch (Exception)
            {
                Response.Write("<script>alert('exception)</script>");
            }
        }

        protected void addBtn_Click(object sender, EventArgs e)
        {
            if (MembershipCategoryDropDown.SelectedValue == "")
            {
                lblError.Text = "**MemberShip Category is required**";
                return;
            }
            else
            {
                Member AddMember = new Member();
                AddMember.AddMember(inputMemberFirstName.Text, inputMemberLastName.Text, inputMemberAddress.Text, Convert.ToDateTime(inputMemberDateOfBirth.Text), MembershipCategoryDropDown.SelectedItem.Value);
                pnlSuccess.Visible = true;
                alrtSuccess.Text = "Member Successfully Added!!";
                Clear();
                ListView();
            }
        }

        protected void updateBtn_Click(object sender, EventArgs e)
        {
            if (MembershipCategoryDropDown.SelectedValue == "")
            {
                lblError.Text = "**MemberShip Category is required**";
                return;
            }
            else
            {
                Member UpdateMember = new Member();
                int id = int.Parse(inputMemberNumber.Text);
                UpdateMember.UpdateMember(id, inputMemberFirstName.Text, inputMemberLastName.Text, inputMemberAddress.Text, Convert.ToDateTime(inputMemberDateOfBirth.Text), MembershipCategoryDropDown.SelectedItem.Value);

                pnlSuccess.Visible = true;
                alrtSuccess.Text = "Member Successfully Updated!!";
                Clear();
                ListView();
            }
        }

        protected void ListView()
        {
            try
            {
                Member p = new Member();
                MemberGV.DataSource = p.GetMember();
                MemberGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }


        protected void GV_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "EditMember":
                        int index = Convert.ToInt32(e.CommandArgument);
                        GridViewRow row = MemberGV.Rows[index];

                        inputMemberNumber.Text = row.Cells[0].Text;
                        inputMemberFirstName.Text = row.Cells[1].Text;
                        inputMemberLastName.Text = row.Cells[2].Text;
                        inputMemberAddress.Text = row.Cells[3].Text;
                        inputMemberDateOfBirth.Text = row.Cells[4].Text;
                        MembershipCategoryDropDown.SelectedItem.Value = row.Cells[5].Text;
                        break;

                    case "DeleteMember":
                        DialogResult dialogResult = MessageBox.Show("Are you Sure??", "Delete Member", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            Member DeleteMember = new Member();
                            int token = Convert.ToInt32(e.CommandArgument);
                            GridViewRow record = MemberGV.Rows[token];

                            DeleteMember.DeleteMember(int.Parse(record.Cells[0].Text));
                            alrtSuccess.Text = "Member Successfully Deleted!!";
                            ListView();
                        }
                        else if (dialogResult == DialogResult.No)
                        {
                            break;
                        }

                        break;

                    default:
                        return;
                }
            }
            catch (Exception ex)
            {
                pnlError.Visible = true;
                alrtError.Text = ex.Message;
            }
        }

        public void Clear()
        {
            inputMemberNumber.Text = "";
            inputMemberFirstName.Text = "";
            inputMemberLastName.Text = "";
            inputMemberAddress.Text = "";
            inputMemberDateOfBirth.Text = "";
            MembershipCategoryDropDown.SelectedIndex = 0;
        }

        protected void clearBtn_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}