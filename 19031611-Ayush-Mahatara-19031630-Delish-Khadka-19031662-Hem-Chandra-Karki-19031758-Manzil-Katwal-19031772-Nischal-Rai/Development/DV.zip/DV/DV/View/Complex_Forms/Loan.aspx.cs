﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;
using System.Windows.Forms;
using MessageBox = System.Windows.Forms.MessageBox;

namespace DV
{
    public partial class WebForm10 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    HttpCookie userCookie = Request.Cookies["userCookie"];
                    if (userCookie == null)
                    {
                        Response.Redirect("~/Login.aspx");
                    }

                    //cookie found
                    if (!string.IsNullOrEmpty(userCookie.Values["userType"]))
                    {
                        string usertype = userCookie.Values["userType"].ToString();
                        if (usertype == "Staff")
                        {
                            Response.Write("<script>alert('welcome Staff')</script>");
                            Response.Redirect("~/403Forbidden.aspx");
                        }
                    }
                    LoanType getLoanType = new LoanType();
                    LoanTypeDropDown.DataSource = getLoanType.GetLoanType();
                    LoanTypeDropDown.DataBind();
                    LoanTypeDropDown.DataTextField = "LoanType";
                    LoanTypeDropDown.DataValueField = "LoanTypeNumber";
                    LoanTypeDropDown.DataBind();
                    LoanTypeDropDown.Items.Insert(0, new ListItem("-- Select Loan Type --", ""));

                    Member getMemberCategory = new Member();
                    MemberDropDown.DataSource = getMemberCategory.GetMember();
                    MemberDropDown.DataBind();
                    MemberDropDown.DataTextField = "MemberFirstName";
                    MemberDropDown.DataValueField = "MemberNumber";
                    MemberDropDown.DataBind();
                    MemberDropDown.Items.Insert(0, new ListItem("-- Select Member --", ""));

                    DVDCopy getDVDCopy = new DVDCopy();
                    DVDCopyDropDown.DataSource = getDVDCopy.GetDVDCopy();
                    DVDCopyDropDown.DataBind();
                    DVDCopyDropDown.DataTextField = "DatePurchased";
                    DVDCopyDropDown.DataValueField = "CopyNumber";
                    DVDCopyDropDown.DataBind();
                    DVDCopyDropDown.Items.Insert(0, new ListItem("-- Select DVD Copy --", ""));
                    ListView();
                }
            }
            catch (Exception)
            {
                Response.Write("<script>alert('exception)</script>");
            }
        }

        protected void addBtn_Click(object sender, EventArgs e)
        {
            if (LoanTypeDropDown.SelectedValue == "" && MemberDropDown.SelectedItem.Value == "" || DVDCopyDropDown.SelectedItem.Value == "")
            {
                lblError.Text = "**Loan Type, Member and DVD Copy is required**";
                return;
            }
            else
            {
                Loan AddLoan = new Loan();
                AddLoan.AddLoan(Convert.ToDateTime(inputDateOut.Text), Convert.ToDateTime(inputDateDue.Text), inputDateReturned.Text, LoanTypeDropDown.SelectedItem.Value, MemberDropDown.SelectedItem.Value, DVDCopyDropDown.SelectedItem.Value);
                pnlSuccess.Visible = true;
                alrtSuccess.Text = "Loan Successfully Added!!";
                Clear();
                ListView();
            }
        }

        protected void updateBtn_Click(object sender, EventArgs e)
        {
            if (LoanTypeDropDown.SelectedValue == "" && MemberDropDown.SelectedItem.Value == "" || DVDCopyDropDown.SelectedItem.Value == "")
            {
                lblError.Text = "**Loan Type, Member and DVD Copy is required**";
                return;
            }
            else
            {
                Loan UpdateMember = new Loan();
                int id = int.Parse(inputLoanNumber.Text);
                UpdateMember.UpdateLoan(id, Convert.ToDateTime(inputDateOut.Text), Convert.ToDateTime(inputDateDue.Text), inputDateReturned.Text, LoanTypeDropDown.SelectedItem.Value, MemberDropDown.SelectedItem.Value, DVDCopyDropDown.SelectedItem.Value);

                pnlSuccess.Visible = true;
                alrtSuccess.Text = "Loan Successfully Updated!!";
                Clear();
                ListView();
            }
        }

        protected void ListView()
        {
            try
            {
                Loan p = new Loan();
                LoanGV.DataSource = p.GetLoan();
                LoanGV.DataBind();
            }

            catch (Exception ex)
            {
                string title = "Error";
                MessageBox.Show(ex.Message, title);
            }
        }


        protected void GV_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "EditLoan":
                        int index = Convert.ToInt32(e.CommandArgument);
                        GridViewRow row = LoanGV.Rows[index];

                        inputLoanNumber.Text = row.Cells[0].Text;
                        inputDateOut.Text = row.Cells[1].Text;
                        inputDateDue.Text = row.Cells[2].Text;
                        inputDateReturned.Text = row.Cells[3].Text;
                        LoanTypeDropDown.SelectedItem.Value = row.Cells[4].Text;
                        MemberDropDown.SelectedItem.Value = row.Cells[5].Text;
                        break;

                    case "DeleteLoan":
                        DialogResult dialogResult = MessageBox.Show("Are you Sure??", "Delete Loan", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            Loan DeleteLoan = new Loan();
                            int token = Convert.ToInt32(e.CommandArgument);
                            GridViewRow record = LoanGV.Rows[token];

                            DeleteLoan.DeleteLoan(int.Parse(record.Cells[0].Text));
                            alrtSuccess.Text = "Loan Successfully Deleted!!";
                            ListView();
                        }
                        else if (dialogResult == DialogResult.No)
                        {
                            break;
                        }

                        break;

                    default:
                        return;
                }
            }
            catch (Exception ex)
            {
                pnlError.Visible = true;
                alrtError.Text = ex.Message;
            }
        }

        public void Clear()
        {
            inputLoanNumber.Text = "";
            inputDateOut.Text = "";
            inputDateDue.Text = "";
            inputDateReturned.Text = "";
            LoanTypeDropDown.SelectedIndex = 0;
            MemberDropDown.SelectedIndex = 0;
        }

        protected void clearBtn_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}