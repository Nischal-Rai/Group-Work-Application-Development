﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DV
{
    public class GlobalConnection
    {
        public SqlConnection connect;
        public GlobalConnection()
        {
            string sqlConnection = System.Configuration.ConfigurationManager
    .AppSettings.Get("MyConnection").ToString();
            connect = new SqlConnection(sqlConnection);
            connect.Open();
        }

    }
}