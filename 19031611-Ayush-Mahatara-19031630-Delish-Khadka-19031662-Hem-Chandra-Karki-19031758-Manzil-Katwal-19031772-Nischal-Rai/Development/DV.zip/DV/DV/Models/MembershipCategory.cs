﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DV
{
    public class MembershipCategory
    {
        public int MembershipCategoryNumber { get; set; }
        public string MembershipCategoryDescription { get; set; }
        public int MembershipCategoryTotalLoans { get; set; }

        GlobalConnection globalConn = new GlobalConnection();

        public void AddMembershipCategory(string MembershipCategoryDescription, int MembershipCategoryTotalLoans)
        {
            SqlCommand sqlCmnd = new SqlCommand("INSERT INTO [MembershipCategory](MembershipCategoryDescription, MembershipCategoryTotalLoans) VALUES (@MembershipCategoryDescription, @MembershipCategoryTotalLoans )", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@MembershipCategoryDescription", MembershipCategoryDescription);
            sqlCmnd.Parameters.AddWithValue("@MembershipCategoryTotalLoans", MembershipCategoryTotalLoans);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public DataTable GetMembershipCategory()
        {

            string userQuery = "SELECT * FROM [MembershipCategory]";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }


        public void UpdateMembershipCategory(int MembershipCategoryNumber, string MembershipCategoryDescription, int MembershipCategoryTotalLoans)
        {
            SqlCommand sqlCmnd = new SqlCommand("UPDATE [MembershipCategory] SET MembershipCategoryDescription = @MembershipCategoryDescription, MembershipCategoryTotalLoans = @MembershipCategoryTotalLoans WHERE MembershipCategoryNumber = @MembershipCategoryNumber", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@MembershipCategoryDescription", MembershipCategoryDescription);
            sqlCmnd.Parameters.AddWithValue("@MembershipCategoryTotalLoans", MembershipCategoryTotalLoans);
            sqlCmnd.Parameters.AddWithValue("@MembershipCategoryNumber", MembershipCategoryNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public void DeleteMembershipCategory(int @MembershipCategoryNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("DELETE FROM [MembershipCategory] WHERE MembershipCategoryNumber = @MembershipCategoryNumber", globalConn.connect);
            sqlCmnd.Parameters.AddWithValue("@MembershipCategoryNumber", MembershipCategoryNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }
    }
}