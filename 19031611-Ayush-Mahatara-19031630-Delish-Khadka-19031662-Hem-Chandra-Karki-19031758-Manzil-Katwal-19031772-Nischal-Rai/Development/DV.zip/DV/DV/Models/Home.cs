﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DV.Models
{
    public class Home
    {
        GlobalConnection globalConn = new GlobalConnection();

        public DataTable GetActor()
        {
            
            string userQuery = "SELECT DISTINCT Actor.ActorSurname, Actor.ActorNumber FROM CastMember LEFT JOIN Actor ON CastMember.ActorNumber = Actor.ActorNumber";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }

        public DataTable GetDVDTitle()
        {
            string userQuery = "SELECT * FROM DVDTitle LEFT JOIN CastMember ON DVDTitle.DVDNumber = CastMember.DVDNumber";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }
        
        public DataTable GetDVDTitle(int ActorNumber)
        {

            string userQuery = "SELECT * FROM DVDTitle LEFT JOIN CastMember ON DVDTitle.DVDNumber = CastMember.DVDNumber WHERE CastMember.ActorNumber =" + ActorNumber;

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }

        public DataTable GetTotalMovies()
        {
            string userQuery = "SELECT CastMember.DVDNumber,DVDTitle.DVDTitle, COUNT(DVDCopy.CopyNumber) AS 'Total Movies' FROM DVDTitle LEFT JOIN CastMember ON DVDTitle.DVDNumber = CastMember.DVDNumber LEFT JOIN DVDCopy ON DVDTitle.DVDNumber = DVDCopy.DVDNumber LEFT JOIN Loan ON DVDCopy.CopyNumber = Loan.CopyNumber AND DVDCopy.CopyNumber NOT IN (SELECT Loan.CopyNumber FROM Loan WHERE Loan.DateReturned IS NULL) GROUP BY CastMember.DVDNumber,DVDTitle.DVDTitle";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }
        
        public DataTable GetTotalMovies(int ActorNumber)
        {
            string userQuery = "SELECT CastMember.DVDNumber,DVDTitle.DVDTitle, COUNT(DVDCopy.CopyNumber) AS 'Total Movies' FROM DVDTitle LEFT JOIN CastMember ON DVDTitle.DVDNumber = CastMember.DVDNumber LEFT JOIN DVDCopy ON DVDTitle.DVDNumber = DVDCopy.DVDNumber LEFT JOIN Loan ON DVDCopy.CopyNumber = Loan.CopyNumber WHERE CastMember.ActorNumber = " + ActorNumber + " AND DVDCopy.CopyNumber NOT IN (SELECT Loan.CopyNumber FROM Loan WHERE Loan.DateReturned IS NULL) GROUP BY CastMember.DVDNumber,DVDTitle.DVDTitle";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }

        public DataTable GetMember()
        {

            string userQuery = "SELECT DISTINCT Member.MemberLastName, Loan.MemberNumber FROM Loan LEFT JOIN Member ON Loan.MemberNumber = Member.MemberNumber WHERE DateOut >= CURRENT_TIMESTAMP-31";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }
        
        public DataTable GetDVDLastMonth()
        {

            string userQuery = "SELECT DVDTitle.DVDNumber, DVDTitle.DVDTitle, DVDCopy.CopyNumber FROM DVDTitle LEFT JOIN DVDCopy ON DVDTitle.DVDNumber = DVDCopy.DVDNumber LEFT JOIN Loan ON DVDCOPY.CopyNumber = Loan.CopyNumber LEFT JOIN Member ON Loan.MemberNumber = Member.MemberNumber WHERE DateOut >= CURRENT_TIMESTAMP-31";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }
        
        public DataTable GetDVDLastMonth(int MemberNumber)
        {

            string userQuery = "SELECT DVDTitle.DVDNumber, DVDTitle.DVDTitle, DVDCopy.CopyNumber FROM DVDTitle LEFT JOIN DVDCopy ON DVDTitle.DVDNumber = DVDCopy.DVDNumber LEFT JOIN Loan ON DVDCOPY.CopyNumber = Loan.CopyNumber LEFT JOIN Member ON Loan.MemberNumber = Member.MemberNumber WHERE DateOut >= CURRENT_TIMESTAMP-31 AND Member.MemberNumber =" + MemberNumber;

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }

        public DataTable GetDVDByOrder()
        {

            string userQuery = "SELECT Producer.ProducerName, Studio.StudioName,Actor.ActorFirstName, DVDTitle.DVDTitle, DVDTitle.DateReleased, Actor.ActorSurname FROM Producer JOIN DVDTitle ON Producer.ProducerNumber = DVDTitle.ProducerNumber JOIN Studio On DVDTitle.StudioNumber = Studio.StudioNumber JOIN CastMember ON DVDTitle.DVDNumber = CastMember.DVDNumber JOIN Actor ON CastMember.ActorNumber = Actor.ActorNumber ORDER BY DVDTitle.DateReleased, Actor.ActorSurname;";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }
        
        public DataTable GetCopyNumber()
        {

            string userQuery = "SELECT DISTINCT DVDCopy.CopyNumber FROM Member JOIN Loan ON Member.MemberNumber = Loan.MemberNumber LEFT JOIN DVDCopy ON Loan.CopyNumber = DVDCopy.CopyNumber;";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }

        public DataTable GetCopyNumberAndDVD()
        {

            string userQuery = "SELECT Loan.MemberNumber, Member.MemberFirstName, Member.MemberLastName, DVDTitle.DVDTitle, Loan.DateOut, Loan.DateDue, Loan.DateReturned FROM Loan LEFT JOIN Member ON Loan.MemberNumber = Member.MemberNumber LEFT JOIN DVDCopy ON Loan.CopyNumber = DVDCopy.CopyNumber LEFT JOIN DVDTitle ON DVDCopy.DVDNumber = DVDTitle.DVDNumber WHERE DVDCopy.CopyNumber= Loan.CopyNumber AND Loan.DateOut IN(SELECT MAX(Dateout) FROM Loan WHERE CopyNumber=Loan.CopyNumber);";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }
        
        public DataTable GetCopyNumberAndDVD(int CopyNumber)
        {

            string userQuery = "SELECT TOP 1 Loan.MemberNumber, Member.MemberFirstName, Member.MemberLastName, DVDTitle.DVDTitle, Loan.DateOut, Loan.DateDue, Loan.DateReturned FROM Loan LEFT JOIN Member ON Loan.MemberNumber = Member.MemberNumber LEFT JOIN DVDCopy ON Loan.CopyNumber = DVDCopy.CopyNumber LEFT JOIN DVDTitle ON DVDCopy.DVDNumber = DVDTitle.DVDNumber WHERE DVDCopy.CopyNumber="+ CopyNumber+ "AND Loan.DateOut IN(SELECT MAX(Dateout) FROM Loan WHERE CopyNumber="+ CopyNumber+ "); ";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable(); 
            sqldataAdapt.Fill(dTable);

            return dTable;
        }
        
        
        public DataTable GetAlphabetMember()
        {

            string userQuery = "SELECT Member.MemberFirstName, Member.MemberLastName, Member.MemberAddress, Member.MemberDateOfBirth, MembershipCategory.MembershipCategoryDescription, count(l.LoanTypeNumber) AS TotalLoan, CASE WHEN(count(l.LoanTypeNumber) < MembershipCategory.MembershipCategoryNumber) THEN 'Normal' ELSE 'Tooo MANY DVDS' END FROM Member JOIN MembershipCategory ON Member.MembershipCategoryNumber = MembershipCategory.MembershipCategoryNumber JOIN Loan l ON l.MemberNumber = Member.MemberNumber GROUP BY Member.MemberFirstName, Member.MemberLastName, Member.MemberAddress, Member.MemberDateOfBirth, MembershipCategory.MembershipCategoryDescription, MembershipCategory.MembershipCategoryNumber; ";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable(); 
            sqldataAdapt.Fill(dTable);

            return dTable;
        }
        
        public DataTable GetDVDNoLoan()
        {

            string userQuery = "SELECT DVDTitle.DVDtitle FROM DVDTitle JOIN DVDCopy ON DVDTitle.DVDNumber = DVDCopy.DVDNumber JOIN Loan ON Loan.CopyNumber =  DVDCopy.CopyNumber WHERE Loan.DateOut < CURRENT_TIMESTAMP - 31; ";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable(); 
            sqldataAdapt.Fill(dTable);

            return dTable;
        }




    }
}