﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DV
{
    public class DVDTitle
    {
        public int DVDNumber { get; set; }
        public string DVDTitle1 { get; set; }
        public decimal StandardCharge { get; set; }
        public decimal PenaltyCharge { get; set; }
        public int CategoryNumber { get; set; }
        public int StudioNumber { get; set; }
        public int ProducerNumber { get; set; }

        GlobalConnection globalConn = new GlobalConnection();

        public void AddDVDTitle(string DVDTitle, decimal StandardCharge, decimal PenaltyCharge, string CategoryNumber, string StudioNumber, string ProducerNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("INSERT INTO [DVDTitle](DVDTitle, StandardCharge, PenaltyCharge, CategoryNumber, StudioNumber, ProducerNumber) VALUES (@DVDTitle1, @StandardCharge, @PenaltyCharge, @CategoryNumber, @StudioNumber, @ProducerNumber)", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@DVDTitle1", DVDTitle);
            sqlCmnd.Parameters.AddWithValue("@StandardCharge", StandardCharge);
            sqlCmnd.Parameters.AddWithValue("@PenaltyCharge", PenaltyCharge);
            sqlCmnd.Parameters.AddWithValue("@CategoryNumber", CategoryNumber);
            sqlCmnd.Parameters.AddWithValue("@StudioNumber", StudioNumber);
            sqlCmnd.Parameters.AddWithValue("@ProducerNumber", ProducerNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public DataTable GetDVDTitle()
        {

            string userQuery = "SELECT * FROM [DVDTitle]";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }


        public void UpdateDVDTitle(int DVDNumber, string DVDTitle, decimal StandardCharge, decimal PenaltyCharge, string CategoryNumber, string StudioNumber, string ProducerNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("UPDATE [DVDTitle] SET DVDTitle = @DVDTitle1, StandardCharge = @StandardCharge, PenaltyCharge = @PenaltyCharge, CategoryNumber = @CategoryNumber, StudioNumber = @StudioNumber, ProducerNumber = @ProducerNumber WHERE DVDNumber = @DVDNumber", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@DVDTitle1", DVDTitle);
            sqlCmnd.Parameters.AddWithValue("@StandardCharge", StandardCharge);
            sqlCmnd.Parameters.AddWithValue("@PenaltyCharge", PenaltyCharge);
            sqlCmnd.Parameters.AddWithValue("@CategoryNumber", CategoryNumber);
            sqlCmnd.Parameters.AddWithValue("@StudioNumber", StudioNumber);
            sqlCmnd.Parameters.AddWithValue("@ProducerNumber", ProducerNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public void DeleteDVDTitle(int @DVDNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("DELETE FROM [DVDTitle] WHERE DVDNumber = @DVDNumber", globalConn.connect);
            sqlCmnd.Parameters.AddWithValue("@DVDNumber", DVDNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }
    }
}