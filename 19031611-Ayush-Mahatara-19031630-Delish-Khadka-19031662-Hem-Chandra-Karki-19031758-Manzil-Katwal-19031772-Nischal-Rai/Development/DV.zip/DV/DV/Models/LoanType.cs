﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DV
{
    public class LoanType
    {
        public int LoanTypeNumber { get; set; }
        public string LoanType1 { get; set; }
        public int LoanDuration { get; set; }

        GlobalConnection globalConn = new GlobalConnection();

        public void AddLoanType(string LoanType, int LoanDuration)
        {
            SqlCommand sqlCmnd = new SqlCommand("INSERT INTO [LoanType](LoanType, LoanDuration) VALUES (@LoanType1, @LoanDuration)", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@LoanType1", LoanType);
            sqlCmnd.Parameters.AddWithValue("@LoanDuration", LoanDuration);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public DataTable GetLoanType()
        {

            string userQuery = "SELECT * FROM [LoanType]";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }


        public void UpdateLoanType(int LoanTypeNumber, string LoanType, int LoanDuration)
        {
            SqlCommand sqlCmnd = new SqlCommand("UPDATE [LoanType] SET LoanType = @LoanType1, LoanDuration = @LoanDuration WHERE LoanTypeNumber = @LoanTypeNumber", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@LoanType1", LoanType);
            sqlCmnd.Parameters.AddWithValue("@LoanDuration", LoanDuration);
            sqlCmnd.Parameters.AddWithValue("@LoanTypeNumber", LoanTypeNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public void DeleteLoanType(int @LoanTypeNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("DELETE FROM [LoanType] WHERE LoanTypeNumber = @LoanTypeNumber", globalConn.connect);
            sqlCmnd.Parameters.AddWithValue("@LoanTypeNumber", LoanTypeNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

    }
}