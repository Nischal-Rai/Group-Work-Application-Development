﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DV
{
    public class DVDCategory
    {
        public int CategoryNumber { get; set; }
        public string CategoryDescription { get; set; }
        public bool AgeRestricted { get; set; }

        GlobalConnection globalConn = new GlobalConnection();

        public void AddDVDCategory(string CategoryDescription, bool AgeRestricted)
        {
            SqlCommand sqlCmnd = new SqlCommand("INSERT INTO [DVDCategory](CategoryDescription, AgeRestricted) VALUES (@CategoryDescription, @AgeRestricted)", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@CategoryDescription", CategoryDescription);
            sqlCmnd.Parameters.AddWithValue("@AgeRestricted", AgeRestricted);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public DataTable GetDVDCategory()
        {

            string userQuery = "SELECT * FROM [DVDCategory]";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }


        public void UpdateDVDCategory(int CategoryNumber, string CategoryDescription, bool AgeRestricted)
        {
            SqlCommand sqlCmnd = new SqlCommand("UPDATE [DVDCategory] SET CategoryDescription = @CategoryDescription, AgeRestricted=@AgeRestricted WHERE CategoryNumber = @CategoryNumber", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@CategoryDescription", CategoryDescription);
            sqlCmnd.Parameters.AddWithValue("@AgeRestricted", AgeRestricted);
            sqlCmnd.Parameters.AddWithValue("@CategoryNumber", CategoryNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public void DeleteDVDCategory(int @CategoryNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("DELETE FROM [DVDCategory] WHERE CategoryNumber = @CategoryNumber", globalConn.connect);
            sqlCmnd.Parameters.AddWithValue("@CategoryNumber", CategoryNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }
    }
}