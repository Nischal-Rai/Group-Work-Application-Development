﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DV
{
    public class DVD
    {
        public int ProducerNumber { get; set; }
        public string ProducerName { get; set; }

        GlobalConnection globalConn = new GlobalConnection();

        public void AddProducer(string ProducerName)
        {
            SqlCommand sqlCmnd = new SqlCommand("INSERT INTO [Producer](ProducerName ) VALUES (@ProducerName )", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@ProducerName", ProducerName);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public DataTable GetProducer()
        {

            string userQuery = "SELECT * FROM [Producer]";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }


        public void UpdateProducer(int ProducerNumber, string ProducerName)
        {
            SqlCommand sqlCmnd = new SqlCommand("UPDATE [Producer] SET ProducerName = @ProducerName WHERE ProducerNumber = @ProducerNumber", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@ProducerName", ProducerName);
            sqlCmnd.Parameters.AddWithValue("@ProducerNumber", ProducerNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public void DeleteProducer(int @ProducerNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("DELETE FROM [Producer] WHERE ProducerNumber = @ProducerNumber", globalConn.connect);
            sqlCmnd.Parameters.AddWithValue("@ProducerNumber", ProducerNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }
    }
}