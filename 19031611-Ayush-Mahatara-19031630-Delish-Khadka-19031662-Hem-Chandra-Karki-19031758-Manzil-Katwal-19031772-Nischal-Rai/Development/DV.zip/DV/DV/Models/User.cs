﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DV
{
    public class User
    {
        public int UserNumber { get; set; }
        public string UserName { get; set; }
        public string UserType { get; set; }
        public string Password { get; set; }

        GlobalConnection globalConn = new GlobalConnection();

        public void AddUser(string UserName, string UserType, string Password)
        {
            SqlCommand sqlCmnd = new SqlCommand("INSERT INTO [User](UserName, UserType, Password) VALUES (@UserName, @UserType, @Password)", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@UserName", UserName);
            sqlCmnd.Parameters.AddWithValue("@UserType", UserType);
            sqlCmnd.Parameters.AddWithValue("@Password", Password);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public DataTable GetUser()
        {

            string userQuery = "SELECT * FROM [User]";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }


        public void UpdateUser(int UserNumber, string UserName, string UserType, string Password)
        {
            SqlCommand sqlCmnd = new SqlCommand("UPDATE [User] SET UserName = @UserName, UserType = @UserType, Password = @Password WHERE UserNumber = @UserNumber", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@UserName", UserName);            
            sqlCmnd.Parameters.AddWithValue("@UserType", UserType);
            sqlCmnd.Parameters.AddWithValue("@Password", Password);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public void DeleteUser(int @UserNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("DELETE FROM [User] WHERE UserNumber = @UserNumber", globalConn.connect);
            sqlCmnd.Parameters.AddWithValue("@UserNumber", UserNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }
    }
}