﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DV
{
    public class Studio
    {
        public int StudioNumber { get; set; }
        public string StudioName { get; set; }

        GlobalConnection globalConn = new GlobalConnection();

        public void AddStudio(string StudioName)
        {
            SqlCommand sqlCmnd = new SqlCommand("INSERT INTO [Studio](StudioName ) VALUES (@StudioName )", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@StudioName", StudioName);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public DataTable GetStudio()
        {

            string userQuery = "SELECT * FROM [Studio]";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }


        public void UpdateStudio(int StudioNumber, string StudioName)
        {
            SqlCommand sqlCmnd = new SqlCommand("UPDATE [Studio] SET StudioName = @StudioName WHERE StudioNumber = @StudioNumber", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@StudioName", StudioName);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public void DeleteStudio(int @StudioNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("DELETE FROM [Studio] WHERE StudioNumber = @StudioNumber", globalConn.connect);
            sqlCmnd.Parameters.AddWithValue("@StudioNumber", StudioNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }
    }
}