﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DV
{
    public class Loan
    {
        public int LoanNumber { get; set; }
        public DateTime DateOut { get; set; }
        public DateTime DateDue { get; set; }
        public string DateReturned { get; set; }
        public int LoanTypeNumber { get; set; }
        public int MemberNumber { get; set; }
        public int CopyNnumber { get; set; }

        GlobalConnection globalConn = new GlobalConnection();

        public void AddLoan(DateTime DateOut, DateTime DateDue, string DateReturned, string LoanTypeNumber, string MemberNumber, string CopyNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("INSERT INTO [Loan](DateOut, DateDue, DateReturned, LoanTypeNumber, MemberNumber, CopyNumber) VALUES (@DateOut, @DateDue, @DateReturned, @LoanTypeNumber, @MemberNumber, @CopyNumber)", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@DateOut", DateOut);
            sqlCmnd.Parameters.AddWithValue("@DateDue", DateDue);
            sqlCmnd.Parameters.AddWithValue("@DateReturned", DateReturned);
            sqlCmnd.Parameters.AddWithValue("@LoanTypeNumber", LoanTypeNumber);
            sqlCmnd.Parameters.AddWithValue("@MemberNumber", MemberNumber);
            sqlCmnd.Parameters.AddWithValue("@CopyNumber", CopyNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public DataTable GetLoan()
        {

            string userQuery = "SELECT * FROM [Loan]";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }


        public void UpdateLoan(int LoanNumber, DateTime DateOut, DateTime DateDue, string DateReturned, string LoanTypeNumber, string MemberNumber, string CopyNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("UPDATE [Loan] SET DateOut = @DateOut, DateDue = @DateDue, DateReturned = @DateReturned, LoanTypeNumber = @LoanTypeNumber, MemberNumber = @MemberNumber, CopyNumber = @CopyNumber WHERE LoanNumber = @LoanNumber", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@DateOut", DateOut);
            sqlCmnd.Parameters.AddWithValue("@DateDue", DateDue);
            sqlCmnd.Parameters.AddWithValue("@DateReturned", DateReturned);
            sqlCmnd.Parameters.AddWithValue("@LoanTypeNumber", LoanTypeNumber);
            sqlCmnd.Parameters.AddWithValue("@MemberNumber", MemberNumber);
            sqlCmnd.Parameters.AddWithValue("@CopyNumber", CopyNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public void DeleteLoan(int @LoanNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("DELETE FROM [Loan] WHERE LoanNumber = @LoanNumber", globalConn.connect);
            sqlCmnd.Parameters.AddWithValue("@LoanNumber", LoanNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

    }
}