﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DV
{
    public class DVDCopy
    {
        public int CopyNumber { get; set; }
        public DateTime DatePurchased { get; set; }
        public int DVDNumber { get; set; }

        GlobalConnection globalConn = new GlobalConnection();

        public void AddDVDCopy(DateTime DatePurchased, string DVDNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("INSERT INTO [DVDCopy](DatePurchased, DVDNumber) VALUES (@DatePurchased, @DVDNumber)", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@DatePurchased", DatePurchased);
            sqlCmnd.Parameters.AddWithValue("@DVDNumber", DVDNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public DataTable GetDVDCopy()
        {

            string userQuery = "SELECT * FROM [DVDCopy] ";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }


        public void UpdateDVDCopy(int CopyNumber, DateTime DatePurchased, string DVDNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("UPDATE [DVDCopy] SET DatePurchased = @DatePurchased, DVDNumber = @DVDNumber WHERE CopyNumber = @CopyNumber", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@DatePurchased", DatePurchased);
            sqlCmnd.Parameters.AddWithValue("@DVDNumber", DVDNumber);
            sqlCmnd.Parameters.AddWithValue("@CopyNumber", CopyNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public void DeleteDVDCopy(int @CopyNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("DELETE FROM [DVDCopy] WHERE CopyNumber = @CopyNumber", globalConn.connect);
            sqlCmnd.Parameters.AddWithValue("@CopyNumber", CopyNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }
    }
}