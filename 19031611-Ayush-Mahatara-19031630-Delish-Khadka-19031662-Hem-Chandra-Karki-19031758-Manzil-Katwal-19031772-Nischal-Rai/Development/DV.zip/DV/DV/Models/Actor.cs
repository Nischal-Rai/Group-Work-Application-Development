﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DV
{
    public class Actor
    {
        public int ActorNumber { get; set; }
        public string ActorFirstName { get; set; }
        public string ActorSurname { get; set; }

        GlobalConnection globalConn = new GlobalConnection();

        public void AddActor(string ActorFirstName, string ActorSurname)
        {
            SqlCommand sqlCmnd = new SqlCommand("INSERT INTO [Actor](ActorFirstName, ActorSurname) VALUES (@ActorFirstName, @ActorSurname)", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@ActorFirstName", ActorFirstName);
            sqlCmnd.Parameters.AddWithValue("@ActorSurname", ActorSurname);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public DataTable GetActor()
        {

            string userQuery = "SELECT * FROM [Actor]";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }


        public void UpdateActor(int ActorNumber, string ActorFirstName, string ActorSurname)
        {
            SqlCommand sqlCmnd = new SqlCommand("UPDATE [Actor] SET ActorFirstName = @ActorFirstName, ActorSurname=@ActorSurname WHERE ActorNumber = @ActorNumber", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@ActorFirstName", ActorFirstName);
            sqlCmnd.Parameters.AddWithValue("@ActorSurname", ActorSurname);
            sqlCmnd.Parameters.AddWithValue("@ActorNumber", ActorNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public void DeleteActor(int @ActorNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("DELETE FROM [Actor] WHERE ActorNumber = @ActorNumber", globalConn.connect);
            sqlCmnd.Parameters.AddWithValue("@ActorNumber", ActorNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }
    }
}