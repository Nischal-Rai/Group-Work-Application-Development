﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DV
{
    public class Member
    {
        public int MemberNumber { get; set; }
        public string MemberFirstName { get; set; }
        public string MemberLastName { get; set; }
        public string MemberAddress { get; set; }
        public DateTime MemberDateOfBirth { get; set; }
        public int MembershipCategoryNumber { get; set; }

        GlobalConnection globalConn = new GlobalConnection();

        public void AddMember(string MemberFirstName, string MemberLastName, string MemberAddress, DateTime MemberDateOfBirth, string MembershipCategoryNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("INSERT INTO [Member](MemberFirstName, MemberLastName, MemberAddress, MemberDateOfBirth, MembershipCategoryNumber) VALUES (@MemberFirstName, @MemberLastName, @MemberAddress, @MemberDateOfBirth, @MembershipCategoryNumber )", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@MemberFirstName", MemberFirstName);
            sqlCmnd.Parameters.AddWithValue("@MemberLastName", MemberLastName);
            sqlCmnd.Parameters.AddWithValue("@MemberAddress", MemberAddress);
            sqlCmnd.Parameters.AddWithValue("@MemberDateOfBirth", MemberDateOfBirth);
            sqlCmnd.Parameters.AddWithValue("@MembershipCategoryNumber", MembershipCategoryNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public DataTable GetMember()
        {

            string userQuery = "SELECT * FROM [Member]";

            SqlDataAdapter sqldataAdapt = new SqlDataAdapter(userQuery, globalConn.connect);

            DataTable dTable = new DataTable();
            sqldataAdapt.Fill(dTable);

            return dTable;
        }


        public void UpdateMember(int MemberNumber, string MemberFirstName, string MemberLastName, string MemberAddress ,DateTime MemberDateOfBirth, string MembershipCategoryNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("UPDATE [Member] SET MemberFirstName = @MemberFirstName, MemberLastName = @MemberLastName, MemberAddress = @MemberAddress,  WHERE MemberNumber = @MemberNumber", globalConn.connect);

            sqlCmnd.Parameters.AddWithValue("@MemberFirstName", MemberFirstName);
            sqlCmnd.Parameters.AddWithValue("@MemberLastName", MemberLastName);
            sqlCmnd.Parameters.AddWithValue("@MemberAddress", MemberAddress);
            sqlCmnd.Parameters.AddWithValue("@MemberDateOfBirth", MemberDateOfBirth);
            sqlCmnd.Parameters.AddWithValue("@MembershipCategoryNumber", MembershipCategoryNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }

        public void DeleteMember(int @MemberNumber)
        {
            SqlCommand sqlCmnd = new SqlCommand("DELETE FROM [Member] WHERE MemberNumber = @MemberNumber", globalConn.connect);
            sqlCmnd.Parameters.AddWithValue("@MemberNumber", MemberNumber);

            sqlCmnd.ExecuteNonQuery();
            globalConn.connect.Close();
        }
    }
}